export class Departments {
    id: number;
    name: string;
};