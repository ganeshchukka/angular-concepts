import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mysql',
  templateUrl: './mysql.component.html',
  styleUrls: ['./mysql.component.css']
})
export class MysqlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
