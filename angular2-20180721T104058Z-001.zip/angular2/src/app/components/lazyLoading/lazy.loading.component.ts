import { Component } from '@angular/core';
@Component({
  selector: 'app-lazy',
  templateUrl: './lazy.loading.component.html'
  })
export class LazyLoadingComponent {
    constructor() {}
}
